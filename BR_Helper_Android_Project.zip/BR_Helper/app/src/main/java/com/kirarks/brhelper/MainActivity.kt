package com.kirarks.brhelper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 17, 22)
    private val panel = Color.rgb(28, 30, 39)
    private val accent = Color.rgb(124, 92, 255)
    private var timer: CountDownTimer? = null
    private lateinit var timerLabel: TextView
    private var remaining = 15 * 60 * 1000L
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 20)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(text("BR HELPER", 27, Color.WHITE, true))
        content.addView(text("Помощник для игры • без игровых макросов", 14, Color.LTGRAY, false).apply {
            setPadding(0, 4, 0, 22)
        })
        content.addView(button("Открыть BLACK RUSSIA") { openGame() })
        content.addView(text("Чек-лист до 4 уровня", 19, Color.WHITE, true).apply {
            setPadding(0, 24, 0, 10)
        })
        val tasks = listOf(
            "Зайти в игру и проверить соединение",
            "Пройти доступное начальное обучение",
            "Выполнить задания, указанные в игре",
            "Проверить текущий уровень персонажа",
            "Остановиться после достижения 4 уровня"
        )
        tasks.forEach { task ->
            val check = CheckBox(this).apply {
                text = task
                textSize = 15f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                setPadding(8, 9, 8, 9)
                background = rounded(panel, 16)
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 8
            content.addView(check, lp)
        }
        content.addView(text("Таймер напоминания", 19, Color.WHITE, true).apply {
            setPadding(0, 18, 0, 8)
        })
        timerLabel = text("15:00", 32, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
            background = rounded(panel, 16)
        }
        content.addView(timerLabel)
        val timerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timerRow.addView(button("15 минут") { setTimer(15) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 5 })
        timerRow.addView(button("30 минут") { setTimer(30) }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 5 })
        content.addView(timerRow)
        content.addView(button("Запустить / остановить таймер") { toggleTimer() })
        content.addView(text("Приложение не создаёт аккаунты и не управляет персонажем автоматически. Оно помогает запускать игру и отмечать свои действия.", 12, Color.GRAY, false).apply {
            setPadding(4, 18, 4, 4)
        })
        setContentView(root)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(accent, 16)
        setPadding(12, 12, 12, 12)
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = 7
        layoutParams = lp
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun openGame() {
        val candidates = listOf("com.br.blackrussia", "com.blackrussia.game", "com.black.russia")
        for (pkg in candidates) {
            try {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    startActivity(launch)
                    return
                }
            } catch (_: Exception) { }
        }
        Toast.makeText(this, "Не удалось найти игру автоматически. Открой BLACK RUSSIA вручную.", Toast.LENGTH_LONG).show()
    }

    private fun setTimer(minutes: Int) {
        timer?.cancel()
        running = false
        remaining = minutes * 60 * 1000L
        updateTimerLabel()
    }

    private fun toggleTimer() {
        if (running) {
            timer?.cancel()
            running = false
            return
        }
        running = true
        timer = object : CountDownTimer(remaining, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remaining = millisUntilFinished
                updateTimerLabel()
            }
            override fun onFinish() {
                running = false
                remaining = 0
                updateTimerLabel()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("BR Helper")
                    .setMessage("Время проверить игру.")
                    .setPositiveButton("ОК", null)
                    .show()
            }
        }.start()
    }

    private fun updateTimerLabel() {
        val totalSeconds = (remaining / 1000).coerceAtLeast(0)
        timerLabel.text = String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60)
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
