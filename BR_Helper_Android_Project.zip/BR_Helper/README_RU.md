# BR Helper — Android

Небольшой Android-помощник с кнопкой запуска игры, чек-листом и таймером. Не управляет персонажем, не регистрирует аккаунты и не нажимает кнопки в игре.

## Как получить APK

В этой среде нет Android SDK/Gradle, поэтому готовый APK здесь не собран. Проект можно открыть в Android Studio на компьютере с установленным Android SDK:

1. Открой папку `BR_Helper` в Android Studio.
2. Дождись синхронизации Gradle.
3. Выбери **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK обычно появится в `app/build/outputs/apk/debug/app-debug.apk`.

Минимальная версия Android: 8.0 (API 26). Требуется интернет при первой синхронизации Gradle.
